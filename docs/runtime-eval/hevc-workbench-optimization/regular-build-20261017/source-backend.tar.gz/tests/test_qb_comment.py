from unittest.mock import MagicMock

import pytest
from qbittorrentapi.exceptions import HTTP404Error, UnsupportedQbittorrentVersion

from app.services import qbittorrent as qb_mod
from app.services.qbittorrent import (
    _ensure_torrent_comment,
    collect_client_info_hashes,
    qb_add_torrent,
)


def _sample_torrent_bytes() -> bytes:
    info = b"d4:name8:test.bin6:lengthi1ee"
    return b"d8:announce14:http://tracker4:info" + info + b"e"


def test_ensure_comment_retries_404_then_overwrites(monkeypatch: pytest.MonkeyPatch) -> None:
    client = MagicMock()
    client.torrents_set_comment.side_effect = [
        HTTP404Error("not ready"),
        None,
    ]
    desired = "https://aniliberty.top/anime/releases/release/x/torrents"
    props_old = MagicMock()
    props_old.comment = "old-from-torrent"
    props_new = MagicMock()
    props_new.comment = desired
    # pre-read (no-op check) → after first set fail → after second set
    client.torrents_properties.side_effect = [props_old, props_new]
    monkeypatch.setattr(qb_mod.time, "sleep", lambda *_: None)

    ok = _ensure_torrent_comment(client, "a" * 40, desired)

    assert ok is True
    assert client.torrents_set_comment.call_count == 2


def test_ensure_comment_overwrites_existing_nonempty(monkeypatch: pytest.MonkeyPatch) -> None:
    """Уже заполненный comment из .torrent должен быть перезаписан URL релиза."""
    client = MagicMock()
    desired = "https://aniliberty.top/anime/releases/release/x/torrents"
    props_old = MagicMock()
    props_old.comment = "comment from .torrent file"
    props_new = MagicMock()
    props_new.comment = desired
    client.torrents_properties.side_effect = [props_old, props_new]
    monkeypatch.setattr(qb_mod.time, "sleep", lambda *_: None)

    ok = _ensure_torrent_comment(client, "b" * 40, desired)

    assert ok is True
    client.torrents_set_comment.assert_called_once_with(
        comment=desired,
        torrent_hashes="b" * 40,
    )


def test_ensure_comment_noop_when_already_desired(monkeypatch: pytest.MonkeyPatch) -> None:
    """Уже верный URL — без setComment, False как у rename no-op."""
    client = MagicMock()
    desired = "https://aniliberty.top/anime/releases/release/x/torrents"
    props = MagicMock()
    props.comment = desired
    client.torrents_properties.return_value = props

    ok = _ensure_torrent_comment(client, "b" * 40, desired)

    assert ok is False
    client.torrents_set_comment.assert_not_called()


def test_ensure_comment_unsupported_version() -> None:
    client = MagicMock()
    client.torrents_set_comment.side_effect = UnsupportedQbittorrentVersion("old")
    qb_mod._comment_unsupported_warned = False

    assert _ensure_torrent_comment(client, "c" * 40, "https://example/x") is False


def test_ensure_comment_require_present_skips_missing() -> None:
    client = MagicMock()
    client.torrents_info.return_value = []

    assert (
        _ensure_torrent_comment(
            client,
            "d" * 40,
            "https://example/x",
            require_present=True,
        )
        is False
    )
    client.torrents_set_comment.assert_not_called()


def test_ensure_comment_retries_when_properties_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    """None из properties больше не считается успехом — нужен повтор."""
    client = MagicMock()
    client.torrents_set_comment.return_value = None
    props_ok = MagicMock()
    props_ok.comment = "https://example/x"
    # pre-read fail → after set fail → after set ok
    client.torrents_properties.side_effect = [
        Exception("not ready"),
        Exception("not ready"),
        props_ok,
    ]
    monkeypatch.setattr(qb_mod.time, "sleep", lambda *_: None)

    ok = _ensure_torrent_comment(client, "e" * 40, "https://example/x")

    assert ok is True
    assert client.torrents_set_comment.call_count == 2


def test_ensure_torrent_tags_noop_when_already_desired(monkeypatch: pytest.MonkeyPatch) -> None:
    client = MagicMock()
    monkeypatch.setattr(
        qb_mod,
        "_read_torrent_tag_list",
        MagicMock(return_value=["Комедия", "Драма"]),
    )

    ok = qb_mod._ensure_torrent_tags(client, "a" * 40, ["Комедия", "Драма"])

    assert ok is False
    client.torrents_add_tags.assert_not_called()
    client.torrents_remove_tags.assert_not_called()


def test_set_comment_after_add_waits_for_torrent(monkeypatch: pytest.MonkeyPatch) -> None:
    client = MagicMock()
    present = [MagicMock(hash="f" * 40, infohash_v1="f" * 40, infohash_v2=None)]
    client.torrents_info.side_effect = [
        [],  # ещё нет
        present,
        present,
    ]
    ensure = MagicMock(return_value=True)
    monkeypatch.setattr(qb_mod, "_ensure_torrent_comment", ensure)
    monkeypatch.setattr(qb_mod.time, "sleep", lambda *_: None)

    ok = qb_mod._set_torrent_comment_after_add(client, "f" * 40, "https://example/x")

    assert ok is True
    ensure.assert_called_once()


def test_collect_client_info_hashes_includes_v1() -> None:
    client = MagicMock()
    t1 = MagicMock()
    t1.hash = "A" * 40
    t1.infohash_v1 = "B" * 40
    t1.infohash_v2 = None
    client.torrents_info.return_value = [t1]

    assert collect_client_info_hashes(client) == {"a" * 40, "b" * 40}


def test_qb_add_torrent_sets_comment_even_when_already_present(monkeypatch: pytest.MonkeyPatch) -> None:
    client = MagicMock()
    client.torrents_add.side_effect = qb_mod.qbittorrentapi.Conflict409Error("exists")
    set_comment = MagicMock(return_value=True)
    monkeypatch.setattr(qb_mod, "_set_torrent_comment_after_add", set_comment)
    monkeypatch.setattr(qb_mod, "_apply_torrent_rename", MagicMock())

    added_new, comment_ok, tags_ok = qb_add_torrent(
        client,
        _sample_torrent_bytes(),
        rename="Name",
        comment="https://aniliberty.top/anime/releases/release/x/torrents",
        category="winter.2024",
    )

    assert added_new is False
    assert comment_ok is True
    assert tags_ok is True
    set_comment.assert_called_once()
    assert set_comment.call_args.args[2].startswith("https://aniliberty.top/")


def test_ensure_torrent_tags_adds_and_verifies(monkeypatch: pytest.MonkeyPatch) -> None:
    client = MagicMock()
    monkeypatch.setattr(qb_mod.time, "sleep", lambda *_: None)
    monkeypatch.setattr(
        qb_mod,
        "_read_torrent_tag_list",
        MagicMock(side_effect=[[], ["Комедия", "Повседневность"]]),
    )
    monkeypatch.setattr(
        qb_mod,
        "_read_torrent_tags",
        MagicMock(side_effect=[set(), {"комедия", "повседневность"}]),
    )

    ok = qb_mod._ensure_torrent_tags(
        client,
        "a" * 40,
        ["Комедия", "Повседневность"],
    )

    assert ok is True
    client.torrents_add_tags.assert_called_once()
    client.torrents_remove_tags.assert_not_called()
