"""Sequential isolated Docker build + import checks; never run benchmarks."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BASES = {"regular": "altt-minijinja-eval:regular-20261017", "ft": "altt-minijinja-eval:ft-20261017"}

def utc():
    return datetime.now(timezone.utc).isoformat()

def execute(args, filename):
    path = ROOT / filename
    if path.exists():
        raise RuntimeError(f"Refuse overwrite {path}")
    start = utc()
    mono = time.monotonic()
    with (ROOT / "commands.jsonl").open("a") as ledger:
        ledger.write(json.dumps({"event": "start", "utc": start, "monotonic": mono, "argv": args, "shell_display": shlex.join(args), "output": str(path)}) + "\n")
    with path.open("x") as log:
        proc = subprocess.run(args, text=True, stdout=log, stderr=subprocess.STDOUT)
    with (ROOT / "commands.jsonl").open("a") as ledger:
        ledger.write(json.dumps({"event": "end", "utc": utc(), "monotonic": time.monotonic(), "returncode": proc.returncode, "output": str(path)}) + "\n")
    if proc.returncode:
        raise RuntimeError(f"Command failed ({proc.returncode}); see {path}")
    return path.read_text()

def main():
    if (ROOT / "commands.jsonl").exists():
        raise RuntimeError("An attempt already exists; preserve its evidence")
    summary = {"created_utc": utc(), "purpose": "isolated c-driver controls, sequential startup/import checks only", "modes": {}, "ok": False}
    execute(["docker", "image", "inspect", "altt-minijinja-eval:build-deps-regular-20261017"], "build-only-image.json")
    for mode, base in BASES.items():
        tag = f"altt-workbench-opt-c:{mode}-20261017"
        if subprocess.run(["docker", "image", "inspect", tag], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            raise RuntimeError(f"Refuse replace existing image {tag}")
        base_info = json.loads(execute(["docker", "image", "inspect", base], f"{mode}-base-image.json"))[0]
        package_script = "import importlib.metadata as m,json;print(json.dumps(dict(sorted((d.metadata['Name'].lower().replace('_','-'),d.version) for d in m.distributions()))))"
        base_packages = json.loads(execute(["docker", "run", "--rm", "--network", "none", "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", base, "python", "-c", package_script], f"{mode}-base-packages.json"))
        execute(["docker", "build", "--network=none", "--progress=plain", "--build-arg", f"BASE_IMAGE={base}", "--tag", tag, "--iidfile", str(ROOT / f"{mode}-image-id.txt"), str(ROOT)], f"{mode}-build.log")
        image_info = json.loads(execute(["docker", "image", "inspect", tag], f"{mode}-image.json"))[0]
        probe = json.loads(execute(["docker", "run", "--rm", "--network", "none", "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", tag, "python", "/opt/altt-c-driver/probe_runtime.py"], f"{mode}-runtime-probe.json"))
        build = json.loads(execute(["docker", "run", "--rm", "--network", "none", "--read-only", tag, "python", "-c", "print(open('/opt/altt-c-driver/build-provenance.json').read(),end='')"], f"{mode}-build-provenance.json"))
        package_diff = {name: {"base": base_packages.get(name), "control": probe["packages"].get(name)} for name in sorted(base_packages.keys() | probe["packages"].keys()) if base_packages.get(name) != probe["packages"].get(name)}
        assert package_diff == {"psycopg-c": {"base": None, "control": "3.3.6"}}, package_diff
        assert probe["ok"]
        assert all(not value for value in probe["compiler_available"].values()), probe["compiler_available"]
        summary["modes"][mode] = {"tag": tag, "base_image_id": base_info["Id"], "image_id": image_info["Id"], "psycopg": probe["psycopg"], "expected_gil": probe["expected_gil"], "checkpoint_count": len(probe["checkpoints"]), "package_diff": package_diff, "wheels": build["wheels"], "warnings": probe["warnings"]}
        print(f"{mode}: built {tag}, backend=c, natural GIL={probe['expected_gil']}", flush=True)
    assert json.loads((ROOT / "regular-runtime-probe.json").read_text())["packages"] == json.loads((ROOT / "ft-runtime-probe.json").read_text())["packages"]
    summary["ok"] = True
    summary["completed_utc"] = utc()
    summary["source_files"] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(ROOT.iterdir()) if path.name in ("Dockerfile", "build_controls.py", "probe_runtime.py", "build_provenance.py", "sources.json", "psycopg_c-3.3.6.tar.gz", "offline-inputs.json", "verify_inputs.py")}
    with (ROOT / "summary.json").open("x") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
