"""SSE change-token'ы для бесшовного обновления UI (без HTMX interval-poll)."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Iterable

from sqlalchemy import func, select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.responses import StreamingResponse
from starlette.types import Send

from app.db.models import (
    FileChangeEvent,
    EncoderSubmission,
    Job,
    JobLog,
    PipelineEvent,
    Release,
    ReleaseMember,
    Setting,
    TelegramOutbox,
    TorrentArchive,
    TorrentFile,
    TorrentPipeline,
    TrackedRelease,
)
from app.db.session import SessionLocal
from app.services.job_runner import STATUS_PENDING, STATUS_RUNNING, STATUS_STOPPING
from app.services.telegram_notify import OUTBOX_PENDING

logger = logging.getLogger(__name__)

SIMPLE_CHANNELS = frozenset(
    {"dashboard", "jobs", "pipeline", "releases", "archive", "info", "encoder", "telegram-outbox", "hevc_workbench"}
)

# Статусы, при которых на pipeline нужен live progress с master/slave (qB).
_ACTIVE_PIPELINE_STATUSES = frozenset(
    {
        "discovered",
        "waiting_master",
        "master_added",
        "master_complete",
        "waiting_slave",
        "slave_added",
    }
)

# 3 с — как _PIPELINE_PROGRESS_TICK_SEC: достаточно для live UI, меньше нагрузки.
_POLL_INTERVAL_SEC = 3.0
_HEARTBEAT_SEC = 15.0
_PIPELINE_PROGRESS_TICK_SEC = 3
_INFO_PROBE_TICK_SEC = 30


def parse_channels(raw: str | None) -> list[str]:
    """Разобрать ?channels=jobs,pipeline,pipeline_detail:12 → уникальный список."""
    if not raw:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for part in raw.split(","):
        ch = part.strip()
        if not ch or ch in seen:
            continue
        if ch in SIMPLE_CHANNELS:
            seen.add(ch)
            out.append(ch)
            continue
        if ch.startswith("pipeline_detail:"):
            suffix = ch.split(":", 1)[1].strip()
            # IDs are PostgreSQL bigint. isdigit() also accepts characters
            # such as ², and an unbounded integer fails during token polling.
            digits = suffix.lstrip("0") or "0"
            if (suffix.isascii() and suffix.isdecimal() and len(digits) <= 19
                    and 0 < int(digits) <= 2**63 - 1):
                normalized = f"pipeline_detail:{int(digits)}"
                if normalized not in seen:
                    seen.add(normalized)
                    out.append(normalized)
    return out


def channel_token(db: Session, channel: str) -> str:
    """Дешёвый fingerprint канала; меняется при реальных изменениях данных."""
    if channel in {"dashboard", "jobs"}:
        return _jobs_token(db)
    if channel == "pipeline":
        return _pipeline_list_token(db)
    if channel.startswith("pipeline_detail:"):
        pid = int(channel.split(":", 1)[1])
        return _pipeline_detail_token(db, pid)
    if channel == "releases":
        return _releases_token(db)
    if channel == "archive":
        return _archive_token(db)
    if channel == "info":
        return _info_token(db)
    if channel == "encoder":
        return _encoder_token(db)
    if channel == "telegram-outbox":
        return _telegram_outbox_token(db)
    if channel == "hevc_workbench":
        return _hevc_workbench_token(db)
    return ""


def _encoder_token(db: Session) -> str:
    row = db.execute(select(func.max(EncoderSubmission.id), func.max(EncoderSubmission.updated_at), func.count().filter(EncoderSubmission.finished_at.is_(None)))).one()
    tick = int(time.time() // 30) if row[2] else ""
    return f"enc:{row[0]}:{row[1]}:{tick}"


def _max_id(db: Session, column) -> int:
    return int(db.scalar(select(func.coalesce(func.max(column), 0))) or 0)


def _jobs_token(db: Session) -> str:
    max_job = _max_id(db, Job.id)
    max_log = _max_id(db, JobLog.id)
    # Сигнатура статусов последних джобов (каталог + таблица).
    rows = db.execute(
        select(Job.id, Job.status, Job.finished_at, Job.started_at, Job.error)
        .order_by(Job.id.desc())
        .limit(40)
    ).all()
    status_sig = "|".join(
        f"{r.id}:{r.status}:{r.finished_at}:{r.started_at}:{bool(r.error)}:{(r.error or '')[:80]}"
        for r in rows
    )
    active = db.scalar(
        select(func.count())
        .select_from(Job)
        .where(Job.status.in_((STATUS_PENDING, STATUS_RUNNING, STATUS_STOPPING)))
    ) or 0
    tick = ""
    if active:
        # Пока есть активные — подтягиваем логи/статусы чаще (max_log уже ловит новые строки).
        tick = f"|a:{int(active)}"
    result_updated = db.scalar(select(func.max(Job.result_updated_at)))
    return f"j:{max_job}|l:{max_log}|s:{status_sig}{tick}|result:{result_updated}"


def _telegram_outbox_token(db: Session) -> str:
    row = db.execute(select(
        func.max(TelegramOutbox.id), func.max(TelegramOutbox.updated_at),
        func.coalesce(func.sum(TelegramOutbox.attempts), 0),
        *[func.count().filter(TelegramOutbox.status == status)
          for status in ("pending", "sending", "failed", "sent", "cancelled")],
    )).one()
    tick = int(time.time() // 15) if row[3] or row[4] else ""
    return "outbox:" + ":".join(str(value) for value in row) + f":{tick}"


def _hevc_workbench_token(db: Session) -> str:
    # Pairing and filesystem probes belong to rendering, never SSE token checks.
    settings_updated = db.scalar(select(func.max(Setting.updated_at)))
    return (f"{_releases_token(db)}|{_jobs_token(db)}|{_encoder_token(db)}|"
            f"settings:{settings_updated}")


def _pipeline_list_token(db: Session) -> str:
    max_pipe = _max_id(db, TorrentPipeline.id)
    max_ev = _max_id(db, PipelineEvent.id)
    rows = db.execute(
        select(
            TorrentPipeline.id,
            TorrentPipeline.status,
            TorrentPipeline.tg_status,
            TorrentPipeline.error,
            TorrentPipeline.master_added_at,
            TorrentPipeline.slave_added_at,
            TorrentPipeline.slave_completed_at,
        )
        .order_by(TorrentPipeline.id.desc())
        .limit(300)
    ).all()
    sig = "|".join(
        f"{r.id}:{r.status}:{r.tg_status}:{(r.error or '')[:80]}:"
        f"{r.master_added_at}:{r.slave_added_at}:{r.slave_completed_at}"
        for r in rows
    )
    # Список больше не показывает live % с qB — tick не нужен (достаточно status/events).
    active = db.scalar(
        select(func.count())
        .select_from(TorrentPipeline)
        .where(TorrentPipeline.status.in_(_ACTIVE_PIPELINE_STATUSES))
    ) or 0
    return f"p:{max_pipe}|e:{max_ev}|s:{sig}|a:{int(active)}"


def _pipeline_detail_token(db: Session, pipeline_id: int) -> str:
    row = db.get(TorrentPipeline, pipeline_id)
    if row is None:
        return f"pd:{pipeline_id}:missing"
    max_ev = db.scalar(
        select(func.coalesce(func.max(PipelineEvent.id), 0)).where(
            PipelineEvent.pipeline_id == pipeline_id
        )
    ) or 0
    tick = ""
    if row.status in _ACTIVE_PIPELINE_STATUSES:
        tick = f"|t:{int(time.time() // _PIPELINE_PROGRESS_TICK_SEC)}"
    return (
        f"pd:{pipeline_id}:{row.status}:{row.tg_status}:{row.error}:"
        f"{row.master_added_at}:{row.slave_added_at}:{row.slave_completed_at}:{max_ev}{tick}"
    )


def _releases_token(db: Session) -> str:
    max_arch = _max_id(db, TorrentArchive.id)
    max_file_ev = _max_id(db, FileChangeEvent.id)
    max_pipe_ev = _max_id(db, PipelineEvent.id)
    max_tf_upd = db.scalar(select(func.max(TorrentFile.updated_at)))
    max_tf_id = _max_id(db, TorrentFile.id)
    tracked = db.scalar(
        select(func.count()).select_from(TrackedRelease).where(TrackedRelease.enabled.is_(True))
    ) or 0
    # Карточка релиза (жанры/блокировки/состав) — отдельно от архива.
    max_rel_upd = db.scalar(select(func.max(Release.updated_at)))
    max_member = _max_id(db, ReleaseMember.id)
    release_flags = db.execute(
        select(
            func.count().filter(Release.is_blocked_by_geo.is_(True)),
            func.count().filter(Release.is_blocked_by_copyrights.is_(True)),
            func.count().filter(Release.is_hidden.is_(True)),
            func.count().filter(Release.is_abandoned.is_(True)),
            func.count().filter(Release.source == "backoffice"),
        )
    ).one()
    # ignore_hevc / api_present / superseded влияют на фильтры и бейджи.
    flag_counts = db.execute(
        select(
            func.count().filter(TorrentArchive.ignore_hevc.is_(True)),
            func.count().filter(TorrentArchive.api_present.is_(True)),
            func.count().filter(TorrentArchive.superseded.is_(True)),
        )
    ).one()
    return (
        f"r:{max_arch}|fe:{max_file_ev}|pe:{max_pipe_ev}|tf:{max_tf_upd}:{max_tf_id}|"
        f"tr:{tracked}|rel:{max_rel_upd}|rm:{max_member}|"
        f"geo:{release_flags[0]}|cr:{release_flags[1]}|hidden:{release_flags[2]}|ab:{release_flags[3]}|bo:{release_flags[4]}|"
        f"ig:{flag_counts[0]}|ap:{flag_counts[1]}|su:{flag_counts[2]}|"
        # Pairing SLA changes with time even when archives/files are unchanged.
        f"sla:{int(time.time() // 60)}"
    )


def _archive_token(db: Session) -> str:
    max_arch = _max_id(db, TorrentArchive.id)
    max_file_ev = _max_id(db, FileChangeEvent.id)
    max_tf_upd = db.scalar(select(func.max(TorrentFile.updated_at)))
    max_tf_id = _max_id(db, TorrentFile.id)
    flag_counts = db.execute(
        select(
            func.count().filter(TorrentArchive.api_present.is_(True)),
            func.count().filter(TorrentArchive.superseded.is_(True)),
        )
    ).one()
    return f"a:{max_arch}|fe:{max_file_ev}|tf:{max_tf_upd}:{max_tf_id}|ap:{flag_counts[0]}|su:{flag_counts[1]}"


def _info_token(db: Session) -> str:
    pending = db.scalar(
        select(func.count())
        .select_from(TelegramOutbox)
        .where(TelegramOutbox.status == OUTBOX_PENDING)
    ) or 0
    max_outbox = _max_id(db, TelegramOutbox.id)
    tracked = db.scalar(
        select(func.count()).select_from(TrackedRelease).where(TrackedRelease.enabled.is_(True))
    ) or 0
    heartbeat = db.scalar(
        select(Setting.value).where(Setting.key == "telegram_bot_heartbeat_at")
    ) or ""
    hevc_heartbeat = db.scalar(select(Setting.value).where(Setting.key == "telegram_hevc_bot_heartbeat_at")) or ""
    # Внешние пробы (qB / AniLibria) — редкий tick, без постоянного HTML-poll.
    tick = int(time.time() // _INFO_PROBE_TICK_SEC)
    return (f"i:{pending}|o:{max_outbox}|tr:{tracked}|hb:{heartbeat}|"
            f"hevc-hb:{hevc_heartbeat}|{_telegram_outbox_token(db)}|t:{tick}")


def _read_channel_tokens(channels: list[str]) -> dict[str, str]:
    """Read one snapshot in a worker thread, closing DB before streaming it."""
    tokens: dict[str, str] = {}
    with SessionLocal() as db:
        for channel in channels:
            try:
                tokens[channel] = channel_token(db, channel)
            except Exception:
                # A failed statement aborts a PostgreSQL transaction. Recover
                # before reading other channels on this connection.
                db.rollback()
                logger.exception("ui_events: token failed for %s", channel)
    return tokens


@dataclass(eq=False)
class _Subscription:
    channels: tuple[str, ...]
    pending: set[str] = field(default_factory=set)
    wake: asyncio.Event = field(default_factory=asyncio.Event)
    closed: bool = False

    async def wait(self, *, timeout: float) -> list[str]:
        """Coalesce invalidations: memory is bounded by subscribed channels."""
        if not self.wake.is_set():
            try:
                await asyncio.wait_for(self.wake.wait(), timeout=timeout)
            except TimeoutError:
                return []
        # No await between taking pending changes and clearing the wake-up.
        self.wake.clear()
        changed = [channel for channel in self.channels if channel in self.pending]
        self.pending.clear()
        return changed


@dataclass(eq=False)
class _ChannelState:
    subscribers: set[_Subscription] = field(default_factory=set)
    token: str | None = None


class UiEventBroadcaster:
    """One DB poller per API lifespan/event loop, only for subscribed channels.

    Subscription state belongs to the API loop; only token reads run in a
    thread. A slow stream never blocks polling or retains a database session.
    """

    def __init__(self, *, poll_interval: float = _POLL_INTERVAL_SEC) -> None:
        self._poll_interval = poll_interval
        self._channels: dict[str, _ChannelState] = {}
        self._subscribers: set[_Subscription] = set()
        self._wake = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._closed = False

    @asynccontextmanager
    async def subscribe(self, channels: Iterable[str]) -> AsyncIterator[_Subscription]:
        if self._closed:
            raise RuntimeError("UI event broadcaster is closed")
        subscriber = _Subscription(tuple(dict.fromkeys(channels)))
        self._subscribers.add(subscriber)
        for channel in subscriber.channels:
            state = self._channels.setdefault(channel, _ChannelState())
            state.subscribers.add(subscriber)
        if self._channels and self._task is None:
            self._task = asyncio.create_task(self._poll(), name="ui-events-poll")
        try:
            yield subscriber
        finally:
            self._subscribers.discard(subscriber)
            subscriber.closed = True
            subscriber.wake.set()
            for channel in subscriber.channels:
                state = self._channels.get(channel)
                if state is not None:
                    state.subscribers.discard(subscriber)
                    if not state.subscribers:
                        del self._channels[channel]
            if not self._channels:
                # Do not cancel an in-flight threadpool read: a new subscriber
                # must reuse this task until its SQL work has actually finished.
                self._wake.set()

    async def _poll(self) -> None:
        try:
            while self._channels and not self._closed:
                self._wake.clear()
                snapshot = self._channels.copy()
                try:
                    tokens = await run_in_threadpool(_read_channel_tokens, list(snapshot))
                    for channel, token in tokens.items():
                        state = snapshot[channel]
                        # A channel can disappear and be subscribed again while
                        # SQL runs. Its old baseline belongs to the old cohort.
                        if self._channels.get(channel) is not state:
                            continue
                        previous = state.token
                        state.token = token
                        if previous is not None and token != previous:
                            for subscriber in state.subscribers:
                                subscriber.pending.add(channel)
                                subscriber.wake.set()
                except Exception:
                    # Preserve baselines across transient DB/session failures.
                    logger.exception("ui_events: poll loop error")
                if not self._channels or self._closed:
                    break
                try:
                    await asyncio.wait_for(self._wake.wait(), timeout=self._poll_interval)
                except TimeoutError:
                    pass
        finally:
            self._task = None

    async def close(self) -> None:
        """Wake streams and drain the only in-flight DB read on API shutdown."""
        self._closed = True
        for subscriber in self._subscribers:
            subscriber.closed = True
            subscriber.wake.set()
        self._subscribers.clear()
        self._channels.clear()
        self._wake.set()
        if self._task is not None:
            await asyncio.shield(self._task)


class UiEventResponse(StreamingResponse):
    """Release subscriptions even if sending a yielded SSE chunk fails."""

    def __init__(self, content: AsyncIterator[str]) -> None:
        super().__init__(
            content,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    async def stream_response(self, send: Send) -> None:
        try:
            await super().stream_response(send)
        finally:
            # StreamingResponse can be interrupted in send(), while the
            # generator is suspended at yield and cannot run its own finally.
            close = getattr(self.body_iterator, "aclose", None)
            if close is not None:
                await close()


async def sse_event_stream(
    request: Request,
    channels: Iterable[str],
    *,
    broadcaster: UiEventBroadcaster,
    heartbeat_sec: float = _HEARTBEAT_SEC,
) -> AsyncIterator[str]:
    """Stream shared channel invalidations, with a per-connection heartbeat."""
    channel_list = list(channels)
    if not channel_list:
        yield ": no-channels\n\n"
        return

    # Сразу первый байт: иначе nginx/OpenResty буферит пустой stream,
    # EventSource/HAR видят status 0 / 0 bytes до первого heartbeat (~15 с).
    yield "retry: 3000\n"
    yield ": connected\n\n"

    last_hb = time.monotonic()
    async with broadcaster.subscribe(channel_list) as subscriber:
        while not subscriber.closed:
            if await request.is_disconnected():
                break
            changed = await subscriber.wait(timeout=min(_POLL_INTERVAL_SEC, heartbeat_sec))
            if subscriber.closed:
                break
            for channel in changed:
                yield f"event: {channel}\ndata: {channel}\n\n"
            now = time.monotonic()
            if now - last_hb >= heartbeat_sec:
                last_hb = now
                yield ": ping\n\n"
