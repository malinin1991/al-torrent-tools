# Isolated psycopg C driver controls

These images add only `psycopg-c==3.3.6` to the matching regular/free-threaded
MiniJinja experiment images. They do not change application files, production
dependency constraints, or the primary pure-driver benchmark series.

The official sdist SHA256 is pinned and checked before building. It includes
Cython-generated C with `Py_MOD_GIL_NOT_USED` declarations for both extensions.
Compiler, headers, setuptools and wheel exist only in the builder stage; the
runtime starts from the unchanged experiment base and receives the built wheel.
Build and runtime libpq versions are recorded separately.

Upstream still describes free-threaded support as experimental, and withholds
binary t-wheels until declaring it complete. The declaration and successful
startup check are not a universal thread-safety claim. This control requires
separate application regression/correctness checks before performance runs.

`probe_runtime.py` runs sequential imports only. It forbids `PYTHON_GIL`, `-X gil`
and `PSYCOPG_IMPL` overrides, asserts naturally selected `c` backend and effective
GIL at startup, after every import and at the end. It makes no database queries
and no performance or concurrency claims. Source links are in `sources.json`.

All build commands and logs, image metadata, wheel hashes, runtime probes and
build provenance are preserved in this directory. Performance runs, if scheduled,
must use a separate output directory from the primary pure-driver series.

Completed 2026-10-17 11:07:52 UTC. Both controls naturally selected `c` with
libpq build/runtime 17.11. Regular effective GIL stayed enabled and FT effective
GIL stayed disabled at all 16 sequential checkpoints. No import warnings.
Package lists are identical across the pair and differ from each base only by
`psycopg-c==3.3.6`. No compiler or pg_config is present in either final runtime.

This successful attempt builds entirely without network access. The existing
build-only image supplies the compiler. Each target runtime supplies its exact
`/usr/local` interpreter/header/config tree to that builder. The checked Debian
libpq-dev package is unpacked only for headers, pg_config and dynamic-link stub;
no SSL-dev dependency is installed. Tool wheels are checked local inputs.
Attempts 01–03 in the parent directory preserve interrupted network/build logs;
they supply no measurements or successful runtime evidence.
