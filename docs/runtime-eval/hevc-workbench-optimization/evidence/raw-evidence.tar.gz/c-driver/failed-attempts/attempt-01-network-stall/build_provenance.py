"""Build evidence only; no application or performance work."""

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import sysconfig

def command(*args):
    return subprocess.check_output(args, text=True).strip()

print(json.dumps({
    "python": sys.version,
    "python_executable": sys.executable,
    "platform": platform.platform(),
    "config": {key: sysconfig.get_config_var(key) for key in ("SOABI", "Py_GIL_DISABLED", "CONFIG_ARGS", "CC", "CFLAGS")},
    "gil_enabled": sys._is_gil_enabled(),
    "build_tools": {name: importlib.metadata.version(name) for name in ("pip", "setuptools", "wheel")},
    "gcc": command("gcc", "--version"),
    "pg_config_version": command("pg_config", "--version"),
    "pg_config_libdir": command("pg_config", "--libdir"),
    "debian_packages": command("dpkg-query", "-W", "-f=${Package} ${Version}\\n", "gcc", "libc6-dev", "libpq-dev", "libpq5"),
    "sdist_sha256": hashlib.sha256(Path("psycopg_c-3.3.6.tar.gz").read_bytes()).hexdigest(),
    "wheels": [{"name": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in sorted(Path("wheels").glob("*.whl"))],
}, indent=2))
