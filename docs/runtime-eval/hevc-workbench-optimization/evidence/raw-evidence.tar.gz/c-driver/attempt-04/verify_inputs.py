import hashlib
import json
from pathlib import Path

for item in json.loads(Path("offline-inputs.json").read_text()):
    assert hashlib.sha256(Path(item["name"]).read_bytes()).hexdigest() == item["sha256"], item["name"]
assert hashlib.sha256(Path("psycopg_c-3.3.6.tar.gz").read_bytes()).hexdigest() == "29c568426ad61c1b702c7d73505c43ca2c9fc5d97a8431d8d9049e731e319ff8"
