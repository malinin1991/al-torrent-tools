from pathlib import Path
import json, subprocess, sys
root=Path('/private/tmp/altt-minijinja-eval-20261017')
tools=Path('/Users/geekaz0id/PycharmProjects/al-torrent-tools/docs/runtime-eval/minijinja-workbench')
results=root/'results-uninterrupted'
records=[json.loads(x) for x in (results/'commands-http.jsonl').read_text().splitlines()]
assert len(records)==64 and all(x['exit_code']==0 for x in records)
for stage in ('render','rendercontrols'):
 print('STAGE',stage,flush=True)
 subprocess.run([sys.executable,str(tools/'run_matrix.py'),'--source',str(root/'frozen/backend'),'--output',str(results),'--stage',stage],check=True)
print('STAGE analyze',flush=True)
subprocess.run([sys.executable,str(tools/'analyze.py'),'--input',str(results),'--output',str(root/'analysis.json')],check=True)
print('STAGE TCP functional smoke',flush=True)
subprocess.run([sys.executable,str(tools/'smoke_preview.py'),'--source',str(root/'frozen/backend'),'--output',str(results)],check=True)
print('ALL TIMING AND TCP CHECKS COMPLETE',flush=True)
