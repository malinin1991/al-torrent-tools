"""Sequential natural-GIL/import provenance; no database, concurrency, or timing claims."""

import argparse
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import sysconfig
import warnings

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    expected = not bool(sysconfig.get_config_var("Py_GIL_DISABLED"))
    record = {
        "ok": False,
        "scope": "sequential startup/import check only; Psycopg free-threaded support remains experimental upstream",
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "config": {key: sysconfig.get_config_var(key) for key in ("SOABI", "Py_GIL_DISABLED", "CONFIG_ARGS", "CC", "CFLAGS")},
        "expected_gil": expected,
        "xoptions": dict(sys._xoptions),
        "environment": {key: os.environ.get(key) for key in ("PYTHON_GIL", "PSYCOPG_IMPL")},
        "checkpoints": [],
        "imports": [],
        "compiler_available": {name: shutil.which(name) for name in ("gcc", "cc", "pg_config")},
    }
    def check(point):
        actual = sys._is_gil_enabled()
        record["checkpoints"].append({"point": point, "gil_enabled": actual})
        if actual != expected:
            raise RuntimeError(f"Effective GIL changed at {point}: {actual}")
    try:
        if os.environ.get("PYTHON_GIL") is not None or "gil" in sys._xoptions:
            raise RuntimeError("Natural mode required: PYTHON_GIL and -X gil overrides forbidden")
        if os.environ.get("PSYCOPG_IMPL") is not None:
            raise RuntimeError("Probe requires default driver selection, without PSYCOPG_IMPL")
        check("startup")
        with warnings.catch_warnings(record=True) as seen:
            warnings.simplefilter("always")
            for name in ("psycopg", "psycopg_c", "psycopg_c.pq", "psycopg_c._psycopg", "sqlalchemy", "fastapi", "starlette", "jinja2", "markupsafe", "minijinja", "minijinja._lowlevel", "blake3", "uvloop", "httptools"):
                module = importlib.import_module(name)
                path = getattr(module, "__file__", None)
                record["imports"].append({"name": name, "path": path, "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest() if path else None})
                check(f"import {name}")
            record["warnings"] = [{"category": item.category.__name__, "message": str(item.message)} for item in seen]
        import psycopg
        assert psycopg.pq.__impl__ == "c", psycopg.pq.__impl__
        assert importlib.metadata.version("psycopg") == "3.3.6"
        assert importlib.metadata.version("psycopg-c") == "3.3.6"
        record["psycopg"] = {"implementation": psycopg.pq.__impl__, "libpq_runtime_version": psycopg.pq.version(), "libpq_build_version": psycopg.pq.__build_version__}
        record["packages"] = dict(sorted((dist.metadata["Name"].lower().replace("_", "-"), dist.version) for dist in importlib.metadata.distributions()))
        record["libpq_package"] = subprocess.check_output(["dpkg-query", "-W", "-f=${Package} ${Version}\\n", "libpq5"], text=True).strip()
        record["linked_libraries"] = {name: subprocess.check_output(["ldd", importlib.import_module(name).__file__], text=True) for name in ("psycopg_c.pq", "psycopg_c._psycopg")}
        check("end")
        record["ok"] = True
    except BaseException as error:
        record["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        payload = json.dumps(record, indent=2) + "\n"
        if args.output:
            args.output.write_text(payload)
        print(payload, end="")

if __name__ == "__main__":
    main()
